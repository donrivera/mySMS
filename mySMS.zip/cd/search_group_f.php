<script type="text/javascript">
self.parent.location.href='certificate.php?student=<?php echo $_REQUEST[student];?>';
self.parent.tb_remove();
</script>