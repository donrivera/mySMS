<?php
ob_start();
session_start();
if(($_COOKIE['cook_username'])=='')
{
	if($_SESSION['id']=="" || $_SESSION['user_type']!="Center Director")
	{
		header("Location:../index.php");
		exit;
	}
}

include_once '../includes/class.Main.php';

$pageTitle='Welcome to Berlitz-KSA';

include 'application_top.php';

//Object initialization
$dbf = new User();
include_once '../includes/language.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome to Berlitz</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<?php
if($_SESSION[font]=='big'){
	?>
    <link rel="stylesheet" type="text/css" href="glowtabs-big.css" />
    <?php
}else if($_SESSION[font]=="small"){
	?>
    <link rel="stylesheet" type="text/css" href="glowtabs-small.css" />
    <?php
}else{
	?>    
    <link rel="stylesheet" type="text/css" href="glowtabs.css" />
    <?php
}
?>
<script type="text/javascript" src="dropdowntabs.js"></script>

<script type="text/javascript" src="../modal/thickbox.js"></script>
<link rel="stylesheet" href="../modal/thickbox.css" type="text/css" media="screen" />

<!--UI JQUERY DATE PICKER-->
<link rel="stylesheet" href="datepicker/jquery.ui.all.css">
<script src="datepicker/jquery.ui.core.js"></script>
<script src="datepicker/jquery.ui.widget.js"></script>
<script src="datepicker/jquery.ui.datepicker.js"></script>
<link rel="stylesheet" href="datepicker/demos.css">

<script>
$(function() {
	$( "#start_date" ).datepicker({
		defaultDate: "+1w",
		changeMonth: true,
		numberOfMonths: 2,
		dateFormat: 'yy-mm-dd',
		onClose: function( selectedDate ) {
			$( "#end_date" ).datepicker( "option", "minDate", selectedDate );
		}
	});
	$( "#end_date" ).datepicker({
		defaultDate: "+1w",
		changeMonth: true,
		numberOfMonths: 2,
		dateFormat: 'yy-mm-dd',
		onClose: function( selectedDate ) {
			$( "#start_date" ).datepicker( "option", "maxDate", selectedDate );
		}
	});
});
</script>

<!--TABLE SORTER-->
<link rel="stylesheet" href="../table_sorter/themes/blue/style.css" type="text/css" media="print, projection, screen" />
<script type="text/javascript" src="../table_sorter/jquery.tablesorter.js"></script>
<script type="text/javascript" src="../table_sorter/addons/pager/jquery.tablesorter.pager.js"></script>
<!--TABLE SORTER-->

<!--table sorter ***************************************************** -->
<script type="text/javascript">
	$(function() {
		$("#sort_table")
			.tablesorter({ 
        // pass the headers argument and assing a object 
        headers: { 
            // assign the secound column (we start counting zero) 
          5: { 
                // disable it by setting the property sorter to false 
                sorter: false 
            }, 
           
        } 
    })
			
			.tablesorterPager({container: $("#pager"), size: 10});
	});
	</script>
<!--*******************************************************************-->
</head>
<script language="Javascript" type="text/javascript">
var countdown;
var countdown_number;

function countdown_init(count) {
    countdown_number = count;
    countdown_trigger();
}

function countdown_trigger(){
    if(countdown_number > 0){
        countdown_number--;
        //document.getElementById('countdown_text').innerHTML = countdown_number;
        if(countdown_number > 0) {
            countdown = setTimeout('countdown_trigger()', 1000);
        }
    }
	if(countdown_number == 0){
		var msg = "Your session has been expired.";
		alert(msg)
		window.location.href='../logout.php';
	}
}
</script>
<?php
//Get from the table
$res_logout = $dbf->strRecordID("conditions","*","type='Logout Time'");
$count = $res_logout["name"]; // Set timeout period in seconds
?>
<body onload="countdown_init(<?php echo $count;?>);">
<?php if($_SESSION[lang] == "EN"){?>
<table <?php if($_SESSION["lang"] == "AR"){?> style="margin-top:-15px;" <?php } ?> width="100%" border="0" align="center" cellpadding="0" cellspacing="0" onclick="countdown_init(<?=$count;?>);">
  <tr>
    <td height="39" align="left" valign="middle" style="padding-left:5px;"><?php include '../top.php';?></td>
  </tr>
  <tr>
    <td height="104" align="left" valign="top"><?php include 'header.php';?></td>
  </tr>
  <tr>
    <td align="left" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="19%" align="left" valign="top"><?php include 'left_menu.php';?></td>
        <td width="2%"><p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p></td>
        <td width="79%" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="left" valign="middle" bgcolor="#b4b4b4" style="background:url(../images/footer_repeat.png) repeat-x;"><table width="100%" border="0" cellspacing="0">
              <tr>
                <td width="54%" height="30" class="logintext"><?php echo constant("CD_VACATION_TEACHER_STATUS_TEACHERVACATION");?></td>
                <td width="22%">&nbsp;</td>
                <td width="8%" align="left">&nbsp;</td>
                <td width="8%" align="left">&nbsp;</td>
                <td width="8%" align="left">&nbsp;</td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td align="left" valign="top" bgcolor="#e6e6e6">
            <form name="frm" id="frm" >
            <table width="100%" border="0" cellpadding="0" cellspacing="0"  bordercolor="#000000" style="border-collapse:collapse;">
			<thead>
              <tr class="logintext">
                <th width="3%" height="25" align="center" valign="middle">&nbsp;</th>
                <th width="5%" align="left" valign="middle" class="pedtext" >From :</th>
                <?php if($_REQUEST[start_date]!=''){
					$start_date = $_REQUEST[start_date];
				}else{
					$start_date = $dbf->MonthFirstDay(date('m'),date('Y'));
				}
				?>
				<th width="12%" align="left" valign="middle" class="pedtext" >
                <input name="start_date" readonly="" type="text" class="datepick validate[required] new_textbox80" id="start_date" value="<?php echo $start_date;?>"/></th>
				 <th width="4%" align="left" valign="middle" class="pedtext" >To :</th>
                 <?php if($_REQUEST[end_date]!=''){
					$end_date = $_REQUEST[end_date];
				}else{
					$end_date = $dbf->MonthLastDay(date('m'),date('Y'));
				}
				?>
                 <th width="10%" align="left" valign="middle" class="pedtext" >                 
                 <input name="end_date" readonly="" type="text" class="datepick validate[required] new_textbox80" id="end_date" value="<?php echo $end_date;?>"/>
                 </th>
                 <th width="66%" colspan="3" align="left" valign="middle" class="pedtext" ><input type="image" src="../images/searchButton.png" width="50" height="22" /></th>
              </tr>
			  </thead>
              
            </table>
            </form>
			<table width="100%" border="1" cellpadding="0" cellspacing="0"  bordercolor="#000000" class="tablesorter" id="sort_table" style="border-collapse:collapse;">
			<thead>
              <tr class="logintext">
                <th width="3%" height="25" align="center" valign="middle" bgcolor="#99CC99" >&nbsp;</th>
                <th width="23%" align="left" valign="middle" bgcolor="#99CC99" class="pedtext" ><?php echo constant("ADMIN_REPORT_TEACHER_BOARD_TEACHERNAME");?> </th>
				<th width="21%" align="left" valign="middle" bgcolor="#99CC99" class="pedtext" ><?php echo constant("ADMIN_VACATION_CENTRE_MANAGE_VACATIONSTART");?> </th>
			    <th width="21%" align="left" valign="middle" bgcolor="#99CC99" class="pedtext" ><?php echo constant("ADMIN_VACATION_CENTRE_MANAGE_VACATIONEND");?></th>
                <th width="24%" align="left" valign="middle" bgcolor="#99CC99" class="pedtext" ><?php echo constant("ADMIN_VACATION_CENTRE_MANAGE_VACATIONTYPE");?></th>
                </tr>
			  </thead>
              <?php
				$i = 1;
				$color = "#ECECFF";
				$num=$dbf->countRows('teacher_vacation v,teacher_centre c',"v.teacher_id=c.teacher_id And c.centre_id='$_SESSION[centre_id]'");
				foreach($dbf->fetchOrder('teacher_vacation v,teacher_centre c',"v.teacher_id=c.teacher_id And c.centre_id='$_SESSION[centre_id]'","id DESC","v.*") as $val) {
				
				$res = $dbf->strRecordID("teacher","*","id='$val[teacher_id]'");
				
				?>
              <tr bgcolor="<?php echo $color;?>" onMouseover="this.bgColor='#FDE6D0'" onMouseout="this.bgColor='<?php echo $color;?>'" style="cursor:pointer;">
              
                <td height="25" align="center" valign="middle" class="mycon"><?php echo $i;?></td>
                <td height="25" align="left" valign="middle" class="mycon" style="padding-left:5px;"><?php echo $res[name];?></td>
				  <td height="25" align="left" valign="middle" class="mycon" style="padding-left:5px;"><?php echo $val[frm];?></td>
				    <td height="25" align="left" valign="middle" class="mycon" style="padding-left:5px;"><?php echo $val[tto];?></td>
                    <td align="left" valign="middle" class="mycon" style="padding-left:5px;"><?php echo $val[type];?></td>
                    <?php
					  $i = $i + 1;
					  if($color=="#ECECFF")
					  {
						  $color = "#E7FEEA";
					  }
					  else
					  {
						  $color="#ECECFF";
					  }
					  
					  }
					  ?>
              </tr>
            </table></td>
          </tr>
		 <?php
					if($num!=0)
					{
					?>
          <tr>
           <td> <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
              <tr>
                <td width="76%" align="center">&nbsp;</td>
                <td width="24%" align="left" ><div id="pager" class="pager" style="text-align:left; padding-top:10px;"> <img src="../table_sorter/icons/first.png" alt="first" width="16" height="16" class="first"/> <img src="../table_sorter/icons/prev.png" alt="prev" width="16" height="16" class="prev"/>
                  <input name="text" type="text" class="pagedisplay trans" size="5" readonly="" style="border:solid 1px; border-color:#FFCC00;"/>
                  <img src="../table_sorter/icons/next.png" width="16" height="16" class="next"/> <img src="../table_sorter/icons/last.png" width="16" height="16" class="last"/>
                  <select name="select" class="pagesize">
                    <option selected="selected"  value="10">10</option>
                    <option value="25">25</option>
                    <option  value="50">50</option>
                  </select>
                </div></td>
              </tr>
			    <?php
				}
					if($num==0)
					{
					?>
              <tr>
                <td height="25" colspan="7" align="center" valign="middle" class="nametext1"><?php echo constant("COMMON_NORECFOUND");?> </td>
              </tr>
              <?php
					}
					?>
              </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" valign="top">&nbsp;</td>
  </tr>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <?php include '../footer.php';?>
</table>  
</table>
<?php }else{?>
<table <?php if($_SESSION["lang"] == "AR"){?> style="margin-top:-15px;" <?php } ?> width="100%" border="0" align="center" cellpadding="0" cellspacing="0" onclick="countdown_init(<?=$count;?>);">
  <tr>
    <td height="39" align="left" valign="middle" style="padding-left:5px;"><?php include '../top_right.php';?></td>
  </tr>
  <tr>
    <td height="104" align="left" valign="top"><?php include 'header_right.php';?></td>
  </tr>
  <tr>
    <td align="left" valign="top">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="2%">&nbsp;</td>
        <td width="78%" align="right" valign="top">
        <table width="98%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="79%" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="left" valign="middle" bgcolor="#b4b4b4" style="background:url(../images/footer_repeat.png) repeat-x;"><table width="100%" border="0" cellspacing="0">
              <tr>
                <td width="54%" height="30" align="right" valign="middle" class="logintext"><?php echo constant("CD_VACATION_TEACHER_STATUS_TEACHERVACATION");?>&nbsp;</td>
                </tr>
              </table></td>
            </tr>
          <tr>
            <td align="left" valign="top" bgcolor="#e6e6e6">
            <form name="frm" id="frm" >
                    <?php if($_REQUEST[start_date]!=''){
					$start_date = $_REQUEST[start_date];
					}else{
						$start_date = $dbf->MonthFirstDay(date('m'),date('Y'));
					}
					if($_REQUEST[end_date]!=''){
						$end_date = $_REQUEST[end_date];
					}else{
						$end_date = $dbf->MonthLastDay(date('m'),date('Y'));
					}
					?>
                    <table width="100%" border="0" cellpadding="0" cellspacing="0"  bordercolor="#000000" style="border-collapse:collapse;">
                    <thead>
                      <tr class="logintext">
                      
                         <th width="66%" colspan="3" align="right" valign="middle" class="pedtext" >
                         <input type="image" src="../images/searchButtonar.png" width="50" height="22" /></th>
                         <th width="10%" align="left" valign="middle" class="pedtext" >                 
                         <input name="end_date" readonly="" type="text" class="datepick validate[required] new_textbox80" id="end_date" value="<?php echo $end_date;?>"/>
                         </th>
                         <th width="4%" align="left" valign="middle" class="pedtext" >: <?php echo constant('ADMIN_REPORT_TEACHER_LEAVE_REPORT_TO');?></th>
                         <th width="12%" align="right" valign="middle" class="pedtext" >
                        <input name="start_date" readonly="" type="text" class="datepick validate[required] new_textbox80" id="start_date" value="<?php echo $start_date;?>"/></th>
                         <th width="5%" align="left" valign="middle" class="pedtext" >: <?php echo constant('ADMIN_REPORT_TEACHER_LEAVE_REPORT_FROM');?></th>
                         <th width="3%" height="25" align="center" valign="middle">&nbsp;</th>
                      </tr>
                      </thead>
                      
                    </table>
            		</form>
              <table width="100%" border="1" cellpadding="0" cellspacing="0"  bordercolor="#000000" class="tablesorter" id="sort_table" style="border-collapse:collapse;">
                <thead>
                  <tr class="logintext">
                    <th width="21%" align="right" valign="middle" bgcolor="#99CC99" class="pedtext" style="padding-right:25px;"><?php echo constant("ADMIN_VACATION_CENTRE_MANAGE_VACATIONSTART");?> </th>
                    <th width="21%" align="right" valign="middle" bgcolor="#99CC99" class="pedtext" style="padding-right:25px;"><?php echo constant("ADMIN_VACATION_CENTRE_MANAGE_VACATIONEND");?></th>
                    <th width="24%" align="right" valign="middle" bgcolor="#99CC99" class="pedtext" style="padding-right:25px;"><?php echo constant("ADMIN_VACATION_CENTRE_MANAGE_VACATIONTYPE");?></th>
                    <th width="23%" align="right" valign="middle" bgcolor="#99CC99" class="pedtext" style="padding-right:25px;"><?php echo constant("ADMIN_REPORT_TEACHER_BOARD_TEACHERNAME");?> </th>
                    <th width="3%" height="25" align="center" valign="middle" bgcolor="#99CC99" >&nbsp;</th>
                    </tr>
                  </thead>
                <?php
				$i = 1;
				$color = "#ECECFF";				
				$cond = '';
				if($_REQUEST[start_date] != '' && $_REQUEST[end_date] != ''){
					$cond = "(v.frm BETWEEN '$_REQUEST[start_date]' And '$_REQUEST[end_date]')";
				}else{
					$cond = "(v.frm BETWEEN '$start_date' And '$end_date')";
				}
				
				$num=$dbf->countRows('teacher_vacation v,teacher_centre c',"v.teacher_id=c.teacher_id And c.centre_id='$_SESSION[centre_id]' And ".$cond);
				foreach($dbf->fetchOrder('teacher_vacation v,teacher_centre c',"v.teacher_id=c.teacher_id And c.centre_id='$_SESSION[centre_id]' And ".$cond,"id DESC","v.*") as $val) {
				
				$res = $dbf->strRecordID("teacher","*","id='$val[teacher_id]'");
				
				?>
                <tr bgcolor="<?php echo $color;?>" onMouseover="this.bgColor='#FDE6D0'" onMouseout="this.bgColor='<?php echo $color;?>'" style="cursor:pointer;">
                  
                  <td height="25" align="right" valign="middle" class="mycon" style="padding-left:5px;"><?php echo $val[frm];?></td>
                  <td height="25" align="right" valign="middle" class="mycon" style="padding-left:5px;"><?php echo $val[tto];?></td>
                  <td align="right" valign="middle" class="mycon" style="padding-left:5px;"><?php echo $val[type];?></td>
                  <td height="25" align="right" valign="middle" class="mycon" style="padding-left:5px;"><?php echo $res[name];?></td>
                  <td height="25" align="center" valign="middle" class="mycon"><?php echo $i;?></td>
                  <?php
					  $i = $i + 1;
					  if($color=="#ECECFF")
					  {
						  $color = "#E7FEEA";
					  }
					  else
					  {
						  $color="#ECECFF";
					  }
					  
					  }
					  ?>
                  </tr>
                </table></td>
            </tr>
          <?php
			if($num > 0)
			{
			?>
          <tr>
            <td> <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
              <tr>
                <td width="76%" align="center">&nbsp;</td>
                <td width="24%" align="left" ><div id="pager" class="pager" style="text-align:left; padding-top:10px;"> <img src="../table_sorter/icons/first.png" alt="first" width="16" height="16" class="first"/> <img src="../table_sorter/icons/prev.png" alt="prev" width="16" height="16" class="prev"/>
                  <input name="text" type="text" class="pagedisplay trans" size="5" readonly="" style="border:solid 1px; border-color:#FFCC00;"/>
                  <img src="../table_sorter/icons/next.png" width="16" height="16" class="next"/> <img src="../table_sorter/icons/last.png" width="16" height="16" class="last"/>
                  <select name="select" class="pagesize">
                    <option selected="selected"  value="10">10</option>
                    <option value="25">25</option>
                    <option  value="50">50</option>
                    </select>
                  </div></td>
                </tr>
              
              </table></td>
            </tr>
        </table></td>
      </tr>     
      <?php
					}
			if($num==0)
			{
			?>
	  <tr>
		<td height="25" colspan="7" align="center" valign="middle" class="nametext1"><?php echo constant("COMMON_NORECFOUND");?> </td>
		</tr>
	  <?php
			}
			?>
    </table>
        
        </td>
        <td width="2%" align="right" valign="top">&nbsp;</td>
        <td width="18%" align="right" valign="top"><?php include 'left_menu_right.php';?></td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top">&nbsp;</td>
  </tr>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <?php include '../footer.php';?>
</table>  
</table>
<?php } ?>
</body>
</html>
